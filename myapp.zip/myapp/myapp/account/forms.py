from django import forms
from django.db import connection


class LoginForm(forms.Form):
    Username = forms.CharField(label='Username',max_length=100)
    Password = forms.CharField(label='Password', max_length=100)

def Project_Name():
    with connection.cursor() as cursor:
        cursor.execute("select DISTINCT ProjectNamevarchar, ProjectNamevarchar from Responstime")
        Project_Name = cursor.fetchall()
    return Project_Name

def Releases():
    with connection.cursor() as cursor:
        cursor.execute("select DISTINCT Releasenumber, Releasenumber from Responstime")
        Releases = cursor.fetchall()
    return Releases

def TypeofTests():
    with connection.cursor() as cursor:
        cursor.execute("select DISTINCT TypeofTest, TypeofTest from Responstime")
        TypeofTests = cursor.fetchall()
    return TypeofTests

def RunId():
    with connection.cursor() as cursor:
        cursor.execute("select DISTINCT RunID, RunID from Responstime")
        RunId = cursor.fetchall()
    return RunId

class p_projectdetails(forms.Form):

    ProjectName = forms.CharField(label='Project Name', widget=forms.Select(choices=Project_Name()))
    Release = forms.CharField(label='Releases', widget=forms.SelectMultiple(choices=Releases()))
    RunId = forms.CharField(label='Run ID', widget=forms.SelectMultiple(choices=RunId()))
    TypeofTests = forms.ChoiceField(label='Type of Tests', widget=forms.Select, choices=TypeofTests())
    # TestDate = forms.ChoiceField(label='Test Date', widget=forms.Select, choices=TestDate)
