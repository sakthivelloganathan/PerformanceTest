from django.http import HttpResponseRedirect
from django.http import HttpResponse
from django.shortcuts import render, render_to_response, redirect
from .forms import LoginForm,p_projectdetails
from django.views import generic
from django.db import connection
from django.views.generic.base import TemplateView, ContextMixin, TemplateResponseMixin,View


class home(TemplateView):
    template_name = 'account/login.html'

    # def get_context_data(self, **kwargs):
    #     context = super().get_context_data(**kwargs)
    #     context['form'] = LoginForm()
    #     return context

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['form'] = p_projectdetails()
        return context

    def database(self):
        with connection.cursor() as cursor:
            cursor.execute("select id, TranscationName, ResponseTime from Responstime where ProjectNamevarchar ='BAUNFT'")
            salad_item = cursor.fetchall()
            # print([salad_item])
            return salad_item

    def post(self, request):
        form = p_projectdetails(request.POST)
        if form.is_valid():
            pProjectName = form.cleaned_data.get('ProjectName')
            pRelease= form.cleaned_data.get('Release')
            pRunId = form.cleaned_data.get('RunId')
            pTypeofTests = form.cleaned_data.get('TypeofTests')
            print(pRelease)
            with connection.cursor() as cursor:
                cursor.execute("select id, TranscationName, ResponseTime "
                               "from Responstime "
                               "where"
                               " ProjectNamevarchar LIKE '%" + pProjectName +"%' AND "  
                               "TypeofTest LIKE '%" + pTypeofTests +"%' "
                                                                    "AND"
                               " Releasenumber IN %s" % str(tuple(pRelease)))
                                                                                # "AND"

                                # "RunID LIKE '%" + pTypeofTests +"%'
                row = cursor.fetchall()
                # listrow = list(row)
                # print(listrow)
            contextres ={'salad':row}
            return render_to_response(self.template_name,contextres)


class Login(TemplateView):
    template_name = 'account/PerformanceDashboard.html'

    def database(self):
        with connection.cursor() as cursor:
            cursor.execute("select username, password from Authorisationtable")
            row = cursor.fetchall()
            print(row)
        return row

    def post(self, request):
        form = LoginForm(request.POST)
        for usrnames in self.database():
            if form.is_valid():
                pusername = form.cleaned_data.get('Username')
                ppassword = form.cleaned_data.get('Password')
                if pusername == usrnames[0]:
                    if ppassword == usrnames[1]:
                        form = p_projectdetails
                        return render(request, self.template_name,{'form': form,'username':pusername})
                    else:
                        return HttpResponse('Login Failed')
                    ''''need to add logic'''
        # form = LoginForm
        # return render(request, 'account/login.html', {'form': form})
        return HttpResponseRedirect('/homepage/')

class PerformanceDashboard(generic.ListView):
    template_name = 'account/Project.html'

    def database(self):
        with connection.cursor() as cursor:
            cursor.execute("select username, password from Authorisationtable")
            row = cursor.fetchall()
        return row

    def post(self,request):
        posts = self.database()
        print(posts)
        # posts = Post.objects.filter(published_date__lte=timezone.now()).order_by('published_date')
        return render(request, 'account/Project.html', {'posts': posts})

    # def post(self, request):
    #     form = p_projectdetails(request.POST)
    #     if form.is_valid():
    #         pProjectName = form.cleaned_data.get('ProjectName')
    #         pRelease = form.cleaned_data.get('Release')
    #         pRunId = form.cleaned_data.get('RunId')
    #         pTypeofTests = form.cleaned_data.get('TypeofTests')
    #         pTestDate = form.cleaned_data.get('TestDate')
    #         context = {
    #                 'form': 60
    #             }
    #         print(context)
    #     return render(request,self.template_name,context)
#
class Logout(TemplateView):
    template_name = 'account/login.html'

    def get(self, request):
        form = 'Logged Out'
        return render(request, self.template_name, {'form': form})
