from django.conf.urls import url
from django.urls import path
from . import views
from account.views import home,Login,PerformanceDashboard,Logout
from django.contrib.auth.decorators import login_required, permission_required

urlpatterns = (
    url(r'^homepage/$',home.as_view(),name='home'),
    # url(r'^homepage/$',somehome.as_view(),name='somehome'),
    url(r'^ProjectsDetails/$',Login.as_view(),name='Login'),
    url(r'^PerformanceDashboard/$',PerformanceDashboard.as_view(),name='PerformanceDashboard'),
    url(r'^logout/$',Logout.as_view(),name='Logout'),
   )