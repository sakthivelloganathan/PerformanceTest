from django.shortcuts import render, redirect, reverse, render_to_response
from django.http import HttpResponse, HttpResponseRedirect
from .forms import LoginForm,ProjectDetail
from django.db import connection
from django.views.generic import TemplateView


# Create your views here.
class Login(TemplateView):
    template_name = 'account/login.html'

    def get(self, request):
        form = LoginForm()
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        with connection.cursor() as cursor:
            cursor.execute("select username, password from Authorisationtable")
            row = cursor.fetchall()
            print(row)
        form = LoginForm(request.POST)
        for usrnames in row:
            if form.is_valid():
                pusername = form.cleaned_data.get('Username')
                ppassword = form.cleaned_data.get('Password')
                print(pusername,ppassword)
                if pusername == usrnames[0]:
                    if ppassword == usrnames[1]:
                        return redirect('/ProjectsDetails/',{'username':usrnames[1]})
            else:
                form = LoginForm ()
                return render(request, self.template_name,{'form': form})

class ProjectsDetails(TemplateView):
    template_name = 'account/PerformanceDashboard.html'

    def get(self, request, *args, **kwargs):
        form = ProjectDetail()
        return render(request, self.template_name, {'form': form})

    def post(self, request, *args, **kwargs):

        form = ProjectDetail(request.POST)
        if form.is_valid():
            pProjectName = form.cleaned_data.get('ProjectName')
            pRelease = form.cleaned_data.get('Release')
            pRunId = form.cleaned_data.get('RunId')
            pTypeofTests = form.cleaned_data.get('TypeofTests')
            pTestDate = form.cleaned_data.get('TestDate')
            print(pProjectName,pRelease,pRunId,pTypeofTests,pTestDate)
            # return render_to_response(self.sucess, {'form': form, 'username': pTestDate})
            return redirect("/PerformanceDashboard/")
        # else:
        #     form = ProjectDetail()
        #     return render(request, self.template_name, {'form': form})

class PerformanceDashboard(TemplateView):
    template_name = 'account/Project.html'

    def post(self, request, *args, **kwargs):
        with connection.cursor() as cursor:
            cursor.execute("select username, password from Authorisationtable")
            row = cursor.fetchall()
            print(row)

    # def get(self, request, *args, **kwargs):
    #     form = ProjectDetail()
    #     return render(request, self.template_name, {'form': form})
    #
    # def post(self, request, *args, **kwargs):
    #     form = ProjectDetail(request.POST)
    #     if form.is_valid():
    #         return HttpResponseRedirect("/Projects/")
    #         # return HttpResponse('<h1>Logout</h1>')
    #        # return render(request, 'accounvbt/Project.html')
    #     else:
    #         form = ProjectDetail()
    # return render(request, self.template_name, {'form': form})

# def Loginpage(request):
#     if request.method == 'POST':
#         form = LoginForm(request.POST or None)
#         for usrnames in Authorisationtable_Query():
#             if form.is_valid():
#                 pusername = form.cleaned_data.get('Username')
#                 ppassword = form.cleaned_data.get('Password')
#                 if pusername == usrnames[0]:
#                     if ppassword == usrnames[1]:
#                         SamppleForm = ProjectDetail()
#                         # return redirect(reverse('Projectdetails/'))
#                         return render(request,'account/Project.html',{'form':SamppleForm})
#                     else:
#                         return HttpResponse('/Incorrect Password/')
#             # return HttpResponse('/Incorrect User name and Password/')
#     else:
#         form = LoginForm()
#         return render(request,'account/login.html',{'form':form})
#
# def Project(request):
#     if request.method == 'POST':
#         sample = ProjectDetail(request.POST)
#         if sample.is_valid():
#             PProjectName = sample.cleaned_data.get('ProjectName')
#             PTestType = sample.cleaned_data.get('TestType')
#             sample = ProjectDetail()
#             return render(request,'account/PerformanceDashboard.html',{'form':sample})
