from django import forms

Project_Name= [
    ('orange', 'Oranges'),
    ('cantaloupe', 'Cantaloupes'),
    ('mango', 'Mangoes'),
    ('honeydew', 'Honeydews'),
    ]

Releases = (('1', 'Single',), ('2', 'Mu',))

TypeofTests = (('1', 'Single',), ('2', 'Mu',))

TestDate = (('1', 'Single',), ('2', 'Mu',))

RunNumber= [
    ('1', '1'),
    ('2', '2'),
    ('3', '3'),
    ('4', '4'),
    ]

class LoginForm(forms.Form):
    Username = forms.CharField(label='Username',max_length=100)
    Password = forms.CharField(label='Password', max_length=100)

class ProjectDetail(forms.Form):
    ProjectName = forms.CharField(label='Project Name',widget=forms.Select(choices=Project_Name))
    Release = forms.CharField(label='Releases', widget=forms.SelectMultiple(choices=Releases))
    RunId = forms.CharField(label='Run ID',widget=forms.SelectMultiple(choices=RunNumber))
    TypeofTests = forms.ChoiceField(label='Type of Tests',widget=forms.Select, choices=TypeofTests)
    TestDate = forms.ChoiceField(label='Test Date', widget=forms.Select, choices=TestDate)