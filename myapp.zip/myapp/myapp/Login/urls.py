from django.conf.urls import url
from django.urls import path
from . import views
from Login.views import Login,ProjectsDetails,PerformanceDashboard

# from django.contrib.auth import login
from django.contrib.auth import views as auth_views

urlpatterns = (
    # url(r'^$', views.Index),
    url(r'^homepage/$', home.as_view(), name=Login),
    url(r'^homepage/$',Login.as_view(),name=Login),
    url(r'^ProjectsDetails/$',ProjectsDetails.as_view(),name=ProjectsDetails),
    url(r'^PerformanceDashboard/$',PerformanceDashboard.as_view(),name=PerformanceDashboard),
    # url(r'^/Projectdetails/$', views.Project,name='Projectdetails'),
    # url(r'^PerformanceDashboard/$', views.PerformanceDashboard, name='PerformanceDashboard'),
    # path('', views.Loginpage, name='Login'),
    # path('Projectdetails/', views.Project, name='Projectdetails'),name='Index'
    # path('', views.Project, name='Projectdetails'),
               )